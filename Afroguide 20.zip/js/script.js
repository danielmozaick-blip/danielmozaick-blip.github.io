// ========== SCRIPT PRINCIPAL POUR AFROGUIDE ==========
document.addEventListener('DOMContentLoaded', () => {
    // ---------- MODE SOMBRE ----------
    const btnDark = document.getElementById('darkModeToggle');
    if (btnDark) {
        if (localStorage.getItem('darkMode') === 'true') {
            document.body.classList.add('dark');
        }
        btnDark.addEventListener('click', () => {
            document.body.classList.toggle('dark');
            localStorage.setItem('darkMode', document.body.classList.contains('dark'));
        });
    }

    // ---------- MENU HAMBURGER (mobile) ----------
    const menuIcon = document.querySelector('.menu-icon');
    const navUl = document.querySelector('nav ul');
    if (menuIcon && navUl) {
        menuIcon.addEventListener('click', () => {
            navUl.classList.toggle('show');
        });
    }

    // ---------- AFFICHAGE IMAGE EN HAUT (remplace la lightbox) ----------
    // Crée un conteneur d'image en haut de la page (juste sous l'en-tête)
    const topImageViewer = document.createElement('div');
    topImageViewer.id = 'top-image-viewer';
    topImageViewer.style.display = 'none';
    const topImage = document.createElement('img');
    topImageViewer.appendChild(topImage);
    
    // Insère ce conteneur après l'en-tête (dans le main ou avant le premier élément)
    const main = document.querySelector('main');
    if (main) {
        main.parentNode.insertBefore(topImageViewer, main);
    } else {
        document.body.insertBefore(topImageViewer, document.body.firstChild);
    }

    // Clic sur une image dans une carte ou une image d'article
    const allImages = document.querySelectorAll('.card img, .article-img');
    allImages.forEach(img => {
        img.addEventListener('click', (e) => {
            e.stopPropagation();
            // Affiche l'image agrandie en haut
            topImage.src = img.src;
            topImageViewer.style.display = 'block';
            
            // Affiche le contenu long associé (toggle)
            const card = img.closest('.card');
            if (card) {
                const contenuComplet = card.querySelector('.contenu-complet');
                if (contenuComplet && !contenuComplet.classList.contains('visible')) {
                    contenuComplet.classList.add('visible');
                    const btn = card.querySelector('.lire-suite');
                    if (btn) btn.textContent = 'Réduire';
                }
            }
        });
    });

    // ---------- TOGGLE "Lire la suite" (sans image) ----------
    const btnsLire = document.querySelectorAll('.lire-suite');
    btnsLire.forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.stopPropagation();
            const card = btn.closest('.card');
            const contenuComplet = card.querySelector('.contenu-complet');
            if (contenuComplet) {
                contenuComplet.classList.toggle('visible');
                btn.textContent = contenuComplet.classList.contains('visible') ? 'Réduire' : 'Lire la suite';
                // Si on réduit, on peut aussi cacher l'image en haut (optionnel)
                if (!contenuComplet.classList.contains('visible') && topImageViewer.style.display === 'block') {
                    topImageViewer.style.display = 'none';
                }
            }
        });
    });
});

// ---------- ALERTE POUR LA BOUTIQUE ----------
window.showMessage = (message) => {
    const alertDiv = document.createElement('div');
    alertDiv.className = 'custom-alert';
    alertDiv.innerText = message;
    document.body.appendChild(alertDiv);
    setTimeout(() => alertDiv.remove(), 3000);
};