// ========== CONFIGURATION CENTRALE POUR AFROGUIDE ==========
// Modifie uniquement les valeurs ci-dessous (remplace les XXXX par tes vrais numéros)

const CONFIG = {
    // Numéros (sans le +, mais avec indicatif, ex: 243812345678)
    whatsappNumber: "243993636691",   // Ton numéro WhatsApp pour recevoir les preuves et envoyer les PDF
    airtelNumber: "243993636691",     // Ton numéro Airtel Money / Orange Money pour les paiements

    // Message affiché quand on clique sur "Acheter" (tu peux le personnaliser)
    payMessage: "📲 Payez par Airtel Money ou Orange Money au +243XXXXXXXX. Envoyez la preuve par WhatsApp au même numéro, puis recevez votre fichier dans les 5 minutes.",

    // Email de contact (optionnel)
    email: "contact@afroguide.com",

    // Liens réseaux sociaux (si tu as des pages)
    facebook: "https://facebook.com/afroguide",
    twitter: "#",
};

// NE RIEN MODIFIER CI-DESSOUS (sauf si tu sais ce que tu fais)
if (typeof module === 'undefined') {
    window.CONFIG = CONFIG;
}